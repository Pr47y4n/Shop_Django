from django.urls import path
from . import views
urlpatterns = [
    path('', views.index, name='index'),
    path('signin', views.log, name='signin'),
    path('reg', views.reg, name='reg'),
    path('myaccount', views.myaccount, name='myaccount'),
    path('addprod', views.addProd, name='addProd'),
    path('shop', views.shop, name='shop'),
    path('blog', views.blog, name='blog')
]