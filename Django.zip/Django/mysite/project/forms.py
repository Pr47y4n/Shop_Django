from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import User
from django import forms
from django.forms import ModelForm

from .models import Products


class UserForm(UserCreationForm):
    email = forms.EmailField(max_length=200, help_text='Required')

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'username', 'email', 'password1', 'password2']

    def __init__(self, *args, **kwargs):
        super(UserForm, self).__init__(*args, **kwargs)
        self.fields['first_name'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'First name',
            'class': "form-control"
        })
        self.fields['last_name'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'Last name',
            'class': "form-control"
        })
        self.fields['username'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'Username',
            'class': "form-control"
        })
        self.fields['email'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'Email',
            'class': "form-control"
        })
        self.fields['password1'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'Password',
            'class': "form-control"
        })
        self.fields['password2'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'Confirm Password',
            'class': "form-control"
        })


class ProductForm(ModelForm):
    class Meta:
        model = Products
        fields = ['name', 'price', 'count', 'description']

    def __init__(self, *args, **kwargs):
        super(ProductForm, self).__init__(*args, **kwargs)
        self.fields['name'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'Prod. Name',
            'class': "form-control"
        })
        self.fields['price'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'Prod. Price',
            'class': "form-control"
        })
        self.fields['count'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'Prod. Count',
            'class': "form-control"
        })
        self.fields['description'].widget.attrs.update({
            'autocomplete': 'off',
            'placeholder': 'Prod. Description',
            'class': "form-control"
        })
#
