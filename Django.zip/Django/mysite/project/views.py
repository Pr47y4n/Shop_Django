from django.shortcuts import render, redirect
from .forms import UserForm, ProductForm  # , ProductForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


# Create your views here.

def index(request):
    return render(request, 'project/index.html')


def log(request):
    if request.method == 'POST':
        user = authenticate(request, username=request.POST.get('username'),
                            password=request.POST.get('password'))
        if user is not None:
            login(request, user)
            return redirect('myaccount')
    return render(request, 'project/signin.html')


def reg(request):
    form = UserForm()
    if request.method == 'POST':
        form = UserForm(request.POST)
        if form.is_valid():
            form = form.save(commit=False)
            form.save()
            return redirect('/project/signin')
    return render(request, 'project/registr.html', {'form': form})


def myaccount(request):
    print(request.user)

    return render(request, 'project/contact.html')


# @login_required(login_url='login')
def addProd(request):
    form = ProductForm()
    data = {
        'form': form,
        'user': request.user
    }
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save(commit=False)
            form.user_id = request.user.id
            print(form.user_id)
            form.save()
            return redirect('project/shop')
    return render(request, 'project/addProduct.html', data)


def shop(request):
    return render(request, 'project/shop.html')


def blog(request):
    return render(request, "project/blog.html")
